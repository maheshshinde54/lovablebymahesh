package com.starter.lovable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LovableApplication {

    public static void main(String[] args)
    {
        SpringApplication.run(LovableApplication.class, args);
    }

}
